export const environment = {
  production: true,
  apiurl:''
};
