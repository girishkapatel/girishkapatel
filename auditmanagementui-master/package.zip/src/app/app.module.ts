import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import {APP_BASE_HREF} from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './common/sidebar/sidebar.component';
import { TopbarComponent } from './common/topbar/topbar.component';
import { FooterComponent } from './common/footer/footer.component';
import { MainComponent } from './common/main/main.component';
import { LoginComponent } from './login/login.component';
import { ApiService } from './services/api/api.service';
import { UtilsService } from "./services/utils/utils.service";
import { LoginService } from "./login/login.service";

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    TopbarComponent,
    FooterComponent,
    MainComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [{provide: APP_BASE_HREF, useValue: '/auditmanagement'}, ApiService, UtilsService, LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
