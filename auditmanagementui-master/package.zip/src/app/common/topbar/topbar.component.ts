import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { Router } from "@angular/router";

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css']
})
export class TopbarComponent implements OnInit {

  constructor(private router:Router) { }
  rolename = "Admin";
  ngOnInit() {
    if(localStorage.getItem('role') && localStorage.getItem('role') === "auditor"){
      this.rolename = "Auditor";
    }
    $('body').attr('class', 'page-header-fixed page-sidebar-closed-hide-logo page-content-white page-footer-fixed page-sidebar-fixed');
  }

  logout(){
    this.router.navigate(['../../login']);
    localStorage.removeItem('userDetails');
    localStorage.removeItem('role');
  }

}
