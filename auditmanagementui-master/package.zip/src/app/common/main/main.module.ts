import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardModule } from "../../pages/dashboard/dashboard.module";
import { ManageauditsModule } from "../../pages/manageaudits/manageaudits.module";
import { ChartsComponent } from '../../common/charts/charts.component';
import { MainComponent } from './main.component';
import { MainRoutingModule } from './main-routing.module';

@NgModule({
    imports: [
        DashboardModule,
        ManageauditsModule,
        MainRoutingModule        
    ],
    declarations: [
        MainComponent,
        ChartsComponent
    ]
})

export class MainModule {}