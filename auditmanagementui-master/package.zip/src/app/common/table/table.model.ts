export interface tableData{
  [key:string]:any
}

export interface tableColumn{
  title:string;
  data:string;
  render?(data?:any, type?:any, row?:any, meta?:any):any;
}