import { Component, OnInit, AfterViewInit, Input, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import 'datatables';
import {tableData, tableColumn} from './table.model';
import { TableService } from './table.service';
import { Observable, Subscription } from 'rxjs';
import { UtilsService } from "../../services/utils/utils.service";
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
  providers:[TableService, UtilsService]
})
export class TableComponent implements OnInit, AfterViewInit, OnDestroy {

  constructor(private tableApi:TableService, private utils:UtilsService) { }

  @Input() tableBehavior?:Observable<string>;  
  @Input() tableId:string = "appTable";
  @Input() tableColumns:tableColumn[] = [];
  @Input('tableApi') tableUrl?:string = '';
  @Input() tableFilters?:Observable<{[key:string]:string}>;  
  @Input() tableScroll?:boolean = false;
  @Input() tableData?:tableData[] = [];
  @Input() tableOrdering?:boolean = true;
  
  tableFiltersData:{[key:string]:string} = {}

  tableSubscription:Subscription;
  tableFilterSubscription:Subscription;

  setupTable(){
    if(this.tableUrl){
      this.tableApi.getTableData(this.tableUrl, this.tableFiltersData).subscribe(posts => {
          this.tableData = posts; 
          $('#'+this.tableId).DataTable().clear().destroy();
          this.initialiseTable();              
      });
    }else{
      this.initialiseTable();
    }
    
  }

  initialiseTable(){
    let tableConfig = {
      "data":this.tableData,
      "bSort": this.tableOrdering,
      "columns":this.tableColumns,
      "scrollX": this.tableScroll,
      "initComplete":function(){}
      
    }

    $('#'+this.tableId).DataTable(tableConfig);
  }

  ngOnInit() {
    if(this.tableFilters){
      this.tableFilterSubscription = this.tableFilters.subscribe(filters => {
        if(!this.utils.isEmptyObj(filters)){
          this.tableFiltersData = filters;  
        }
        this.setupTable();
      }, error=>{
        console.log(error);
      });
    }
    
    if(this.tableBehavior){
      this.tableSubscription = this.tableBehavior.subscribe(item => {
        if(item === 'load'){
          this.setupTable();
        }
      });
    }
  }
  
  ngAfterViewInit(): void {
    this.initialiseTable();
  }

  ngOnDestroy(){
    if(this.tableFilterSubscription){
      this.tableFilterSubscription.unsubscribe();
    }

    if(this.tableSubscription){
      this.tableSubscription.unsubscribe();
    }
    
    
  }
  
}
