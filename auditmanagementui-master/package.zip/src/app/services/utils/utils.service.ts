import { Injectable } from '@angular/core';

@Injectable()
export class UtilsService {
    
    constructor() { }

    isEmptyObj(obj:any) {
        for(var prop in obj) {
            if(obj.hasOwnProperty(prop)){
                return false;
            }
        }
        return true;
    }
}