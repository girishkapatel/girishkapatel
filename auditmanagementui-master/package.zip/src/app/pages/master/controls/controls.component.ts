import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { ControlsService } from './controls.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-controls',
  templateUrl: './controls.component.html',
  styleUrls: ['./controls.component.css'],
  providers:[ControlsService]
})
export class ControlsComponent implements OnInit{

  constructor(private controls:ControlsService) { }
  
  @ViewChild('controlsForm', {static:false}) controlsForm:NgForm;

  tableId:string = "controls_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Control Title',
    data:'name'
  },{
    title:'Control ID',
    data:'cid'
  },{
    title:'Control Description',
    data:'desc'
  },{
    title:'Control Nature',
    data:'nature'
  },{
    title:'Control Frequency',
    data:'freq'
  },{
    title:'Control Owner',
    data:'owner'
  },{
    title:'Control Type',
    data:'type'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editControls"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    cid:'PTP.C.01',
    name:'System restriction to process duplicate payment',
    desc:'System restricts booking of duplicate invoice based on the invoice number, invoice date and vendor name/code',
    nature:'Automated',
    freq:'Event driven',
    owner:'Mr. Sambhaji More',
    type:''
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveControls(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateControls();
    }else{
      this.addNewControls();
    }
  }

  addNewControls(){
    let postData = this.controlsForm.form.value;
    console.log(postData);
    this.controls.addControls('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateControls(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.controls.updateControls('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addControls(){
    this.handleFormView.show();
  }

  editControls(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteControls(){
    this.controls.deleteControls('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editControls', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editControls();
        })
    })
  }
 
  
}
