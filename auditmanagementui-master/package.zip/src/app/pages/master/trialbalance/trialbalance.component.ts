import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { TrialbalanceService } from './trialbalance.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-trialbalance',
  templateUrl: './trialbalance.component.html',
  styleUrls: ['./trialbalance.component.css'],
  providers:[TrialbalanceService]
})
export class TrialbalanceComponent implements OnInit{

  constructor(private trialbalance:TrialbalanceService) { }
  
  @ViewChild('trialbalanceForm', {static:false}) trialbalanceForm:NgForm;

  tableId:string = "trialbalance_table";
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'GL Code',
    data:'glcode'
  },{
    title:'GL Description',
    data:'gldesc'
  },{
    title:'Process L2',
    data:'process'
  },{
    title:'Balance (INR)',
    data:'total'
  },{
    title:'Location',
    data:'location',
    render:(location)=>{

      let tbodyHtml = '';
      //'<tr><td colspan="3">No Records Found</td></tr>';
      for(let info of location){
        tbodyHtml += '<tr>';
        tbodyHtml += '<td>'+ info.name + ' ('+info.pcc+')' +'</td>';
        tbodyHtml += '<td>'+ info.division +'</td>';
        tbodyHtml += '<td>'+ info.balance +'</td>';
        tbodyHtml += '</tr>';
      }

      return `
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Location</th>
              <th>Division</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>
              ${tbodyHtml}
          </tbody>
        </table>
      `;
    }
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editTrialbalance"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
	id:1,
	glcode:'TCH3364',
	gldesc:'Trade Payables',
	process:'Accounts Payable',
	total:'-43,033.72 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'-326.0876678'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'-130.2111882'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'-736.3658624'
		}
		
	]
},
{
	id:2,
	glcode:'TCH3523',
	gldesc:'Sundry creditors',
	process:'Accounts Payable',
	total:'-25,070.90 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'-128.6778881'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'-130.2111882'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'-441.6509808'
		}
		
	]
},
{
	glcode:'TCH3530',
	gldesc:'Provision for expens',
	process:'Accounts Payable',
	total:'-49.62 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'0'
		}
		
	]
},
{
	glcode:'TCH3365',
	gldesc:'Other Payables',
	process:'Accounts Payable',
	total:'-5,005.55 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'0'
		}
		
	]
},
{
	glcode:'TCH3431',
	gldesc:'Outstanding payable',
	process:'Accounts Payable',
	total:'-5,005.55 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'0'
		}
		
	]
},
{
	glcode:'TCH3155',
	gldesc:'Purchase of stock in',
	process:'Accounts Payable',
	total:'14,950.74 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'356.86125'
		}
		
	]
},
{
	glcode:'TCH3199',
	gldesc:'Traded goods purchas',
	process:'Accounts Payable',
	total:'14,950.74 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'356.86125'
		}
		
	]
},
{
	glcode:'TCH3207',
	gldesc:'Discount on traded g',
	process:'Accounts Payable',
	total:'0.00 INR',
	location:[
		{
			name:'Mithapur',
			division:'BI Carb Group',
			pcc:'TCL/BICA',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Bio Fuels',
			pcc:'TCL/BIOF',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement Admixtures',
			pcc:'TCL/CADM',
			balance:'0'
		},
		{
			name:'Mithapur',
			division:'Cement',
			pcc:'TCL/CEMT',
			balance:'0'
		}
		
	]	
}]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});
  totalbalance:string = "";  
  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveTrialbalance(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateTrialbalance();
    }else{
      this.addNewTrialbalance();
    }
  }

  addNewTrialbalance(){
    
    // let postData = this.trialbalanceForm.form.value;
    // console.log(postData);
    // this.trialbalance.addTrialbalance('posts', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  updateTrialbalance(){
    // let postData = {
    //   id: 1,
    //   title: 'foo',
    //   body: 'bar',
    //   userId: 1
    // }

    // this.trialbalance.updateTrialbalance('posts/1', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  addTrialbalance(){
    this.totalbalance = "";
    this.handleFormView.show();
  }

  editTrialbalance(){
    this.isEdit = true;
    this.totalbalance = "20.8778376";
    this.handleFormView.show();
  }

  deleteTrialbalance(){
    this.trialbalance.deleteTrialbalance('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editTrialbalance', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editTrialbalance();
        })
    })
  }
 
  
}
