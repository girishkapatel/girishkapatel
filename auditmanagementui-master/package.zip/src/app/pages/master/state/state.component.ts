import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
// import { StateService } from './state.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css'],
  providers:[]
})
export class StateComponent implements OnInit{

  constructor() { }
  
  @ViewChild('stateForm', {static:false}) stateForm:NgForm;

  tableId:string = "state_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'State Name',
    data:'name'
  },{
    title:'Country',
    data:'country'
  },{
    title:'Status',
    data:'status'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editState"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Maharashtra',
    country:'India',
    status:'Active'
  },{
    id:1,
    name:'Delhi',
    country:'India',
    status:'Active'
  },{
    id:1,
    name:'Gujarat',
    country:'India',
    status:'Active'
  },{
    id:1,
    name:'Rajasthan',
    country:'India',
    status:'Active'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveState(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateState();
    }else{
      this.addNewState();
    }
  }

  addNewState(){
    let postData = this.stateForm.form.value;
    console.log(postData);
    // this.state.addState('posts', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  updateState(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    // this.state.updateState('posts/1', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  addState(){
    this.handleFormView.show();
  }

  editState(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteState(){
    // this.state.deleteState('post/1').subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editState', (e)=>{
            //let dataId = $(e.target).attr('data-id');
            this.editState();
        })
    })
  }
 
  
}
