import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
// import { CompanyService } from './company.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css'],
  providers:[]
})
export class CompanyComponent implements OnInit{

  constructor() { }
  
  @ViewChild('companyForm', {static:false}) companyForm:NgForm;

  tableId:string = "company_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Company Name',
    data:'name'
  },{
    title:'Division',
    data:'division'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editCompany"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Tata Chemical Limited',
    division:'Chemical'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveCompany(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateCompany();
    }else{
      this.addNewCompany();
    }
  }

  addNewCompany(){
    let postData = this.companyForm.form.value;
    console.log(postData);
    // this.company.addCompany('posts', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  updateCompany(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    // this.company.updateCompany('posts/1', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  addCompany(){
    this.handleFormView.show();
  }

  editCompany(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteCompany(){
    // this.company.deleteCompany('post/1').subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editCompany', (e)=>{
            //let dataId = $(e.target).attr('data-id');
            this.editCompany();
        })
    })
  }
 
  
}
