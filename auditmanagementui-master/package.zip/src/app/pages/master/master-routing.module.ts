import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterComponent } from './master.component';
import { CountryComponent } from './country/country.component';
import { CityComponent } from './city/city.component';
import { StateComponent } from './state/state.component';
import { AuditPlanComponent } from './auditplans/auditplans.component';
import { CompanyComponent } from './company/company.component';
import { LocationComponent } from './location/location.component';
import { ProcessComponent } from './process/process.component';
import { ControlsComponent } from './controls/controls.component';
import { RisksComponent } from './risks/risks.component';
import { KeybusinessinitiativeComponent } from './keybusinessinitiative/keybusinessinitiative.component';
import { ProcessriskmappingComponent } from './processriskmapping/processriskmapping.component';
import { DatarequestComponent } from './datarequest/datarequest.component';
import { TrialbalanceComponent } from './trialbalance/trialbalance.component';
import { BenchmarksComponent } from './benchmarks/benchmarks.component';

const routes: Routes = [
  {
    path: '',
    component: MasterComponent,
    data: {
      title: 'Master'
    },
    children:[
      {
        path: '',
        redirectTo: 'location',
        pathMatch: 'full',
      },
      {
        path: 'country',
        component: CountryComponent
      },
      {
        path: 'city',
        component: CityComponent
      },
      {
        path: 'state',
        component: StateComponent
      },
      {
        path: 'company',
        component: CompanyComponent
      },
      {
        path: 'location',
        component: LocationComponent
      },
      {
        path: 'auditplans',
        component: AuditPlanComponent
      },
      {
        path:'process',
        component:ProcessComponent
      },
      {
        path:'risks',
        component:RisksComponent
      },
      {
        path:'controls',
        component:ControlsComponent
      },{
        path:'keybusinessinitiative',
        component:KeybusinessinitiativeComponent
      },
      {
        path:'processriskmapping',
        component:ProcessriskmappingComponent
      },
      {
        path:'datarequest',
        component:DatarequestComponent
      },
      {
        path:'trialbalance',
        component:TrialbalanceComponent
      },
      {
        path:'benchmarks',
        component:BenchmarksComponent
      }
             
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class MasterRoutingModule {}