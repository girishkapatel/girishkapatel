import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
// import { LocationService } from './location.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css'],
  providers:[]
})
export class LocationComponent implements OnInit{

  constructor() { }
  
  @ViewChild('locationForm', {static:false}) locationForm:NgForm;

  tableId:string = "location_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Company Name',
    data:'name'
  },{
    title:'Division',
    data:'division'
  },{
    title:'Profit Center Code',
    data:'pcc'
  },{
    title:'Criticality',
    data:'criticality'
  },{
    title:'Country',
    data:'country'
  },{
    title:'State',
    data:'state'
  },{
    title:'City',
    data:'city'
  },{
    title:'Location ID',
    data:'lid'
  },
  {
    title:'Location Description',
    data:'ldesc'
  },
  {
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editLocation"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Tata Chemical Limited',
    division:'Chemistry Solutions',
    pcc:"TCL/AMAT",
    criticality:"HIGH",
    country:'India',
    state:'Gujarat',
    city:'Mithapur',
    lid:"E01D02C01L01",
    ldesc:'Mithapur Plant'
  },
  {
    id:1,
    name:'Tata Chemical Limited',
    division:'BI Carb Group',
    pcc:"TCL/BICA",
    criticality:"HIGH",
    country:'India',
    state:'Gujarat',
    city:'Mithapur',
    lid:"E01D02C01L02",
    ldesc:'Mithapur Plant'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveLocation(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateLocation();
    }else{
      this.addNewLocation();
    }
  }

  addNewLocation(){
    let postData = this.locationForm.form.value;
    console.log(postData);
    // this.location.addLocation('posts', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  updateLocation(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    // this.location.updateLocation('posts/1', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  addLocation(){
    this.handleFormView.show();
  }

  editLocation(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteLocation(){
    // this.location.deleteLocation('post/1').subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editLocation', (e)=>{
            //let dataId = $(e.target).attr('data-id');
            this.editLocation();
        })
    })
  }
 
  
}
