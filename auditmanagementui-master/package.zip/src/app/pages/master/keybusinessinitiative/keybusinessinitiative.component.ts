import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { KeybusinessinitiativeService } from './keybusinessinitiative.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-keybusinessinitiative',
  templateUrl: './keybusinessinitiative.component.html',
  styleUrls: ['./keybusinessinitiative.component.css'],
  providers:[KeybusinessinitiativeService]
})
export class KeybusinessinitiativeComponent implements OnInit{

  constructor(private keybusinessinitiative:KeybusinessinitiativeService) { }
  
  @ViewChild('keybusinessinitiativeForm', {static:false}) keybusinessinitiativeForm:NgForm;

  tableId:string = "keybusinessinitiative_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'BI Title',
    data:'name'
  },{
    title:'BI ID',
    data:'biId'
  },{
    title:'Description',
    data:'desc'
  },{
    title:'Business Cycle ',
    data:'l1process'
  },{
    title:'Process L1',
    data:'l2process'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editKeybusinessinitiative"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    biId:'E01',
    name:'Invoice Automation',
    desc:'Automation of invoice processing',
    l1process:'Procure To Pay',
    l2process:'Account Payable'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveKeybusinessinitiative(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateKeybusinessinitiative();
    }else{
      this.addNewKeybusinessinitiative();
    }
  }

  addNewKeybusinessinitiative(){
    let postData = this.keybusinessinitiativeForm.form.value;
    console.log(postData);
    this.keybusinessinitiative.addKeybusinessinitiative('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateKeybusinessinitiative(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.keybusinessinitiative.updateKeybusinessinitiative('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addKeybusinessinitiative(){
    this.handleFormView.show();
  }

  editKeybusinessinitiative(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteKeybusinessinitiative(){
    this.keybusinessinitiative.deleteKeybusinessinitiative('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editKeybusinessinitiative', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editKeybusinessinitiative();
        })
    })
  }
 
  
}
