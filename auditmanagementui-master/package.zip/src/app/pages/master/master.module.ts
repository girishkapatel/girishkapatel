import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MasterComponent } from "./master.component";
import { MasterRoutingModule } from './master-routing.module';
import { CountryComponent } from './country/country.component';
import { CityComponent } from './city/city.component';
import { StateComponent } from './state/state.component';
import { CompanyComponent } from './company/company.component';
import { LocationComponent } from './location/location.component';
import { AuditPlanComponent } from './auditplans/auditplans.component';
import { ProcessComponent } from './process/process.component';
import { RisksComponent } from './risks/risks.component';
import { ControlsComponent } from './controls/controls.component';
import { TableModule } from '../../common/table/table.module';
import { CityService } from './city/city.service';
import { CountryService } from './country/country.service';
import { KeybusinessinitiativeComponent } from './keybusinessinitiative/keybusinessinitiative.component';
import { ProcessriskmappingComponent } from './processriskmapping/processriskmapping.component';
import { DatarequestComponent } from './datarequest/datarequest.component';
import { TrialbalanceComponent } from './trialbalance/trialbalance.component';
import { BenchmarksComponent } from './benchmarks/benchmarks.component';
import { BusinessProcessComponent } from './process/businessprocess/businessprocess.component';
import { ProcessLevel1Component } from './process/processlevel1/processlevel1.component';
import { ProcessLevel2Component } from './process/processlevel2/processlevel2.component';
@NgModule({
    imports: [
        CommonModule,
        MasterRoutingModule,
        FormsModule,
        TableModule      
    ],
    declarations: [
        MasterComponent,
        CountryComponent,
        CityComponent,
        StateComponent,
        CompanyComponent,
        LocationComponent,
        AuditPlanComponent,
        ProcessComponent,
        RisksComponent,
        ControlsComponent,
        KeybusinessinitiativeComponent,
        ProcessriskmappingComponent,
        DatarequestComponent,
        TrialbalanceComponent,
        BusinessProcessComponent,
        ProcessLevel1Component,
        ProcessLevel2Component,
        BenchmarksComponent
    ],
    providers:[CityService, CountryService]
})

export class MasterModule {}