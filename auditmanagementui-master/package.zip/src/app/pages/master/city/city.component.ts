import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
// import { CityService } from './city.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css'],
  providers:[]
})
export class CityComponent implements OnInit{

  constructor() { }
  
  @ViewChild('cityForm', {static:false}) cityForm:NgForm;

  tableId:string = "city_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'City Name',
    data:'name'
  },{
    title:'State',
    data:'state'
  },{
    title:'Country',
    data:'country'
  },{
    title:'Status',
    data:'status'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editCity"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Mumbai',
    state:'Maharashtra',
    country:'India',
    status:'Active'
  },{
    id:1,
    name:'Pune',
    state:'Maharashtra',
    country:'India',
    status:'Active'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveCity(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateCity();
    }else{
      this.addNewCity();
    }
  }

  addNewCity(){
    let postData = this.cityForm.form.value;
    console.log(postData);
    // this.city.addCity('posts', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  updateCity(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    // this.city.updateCity('posts/1', postData).subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  addCity(){
    this.handleFormView.show();
  }

  editCity(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteCity(){
    // this.city.deleteCity('post/1').subscribe(response=>{
    //   console.log(response);
    //   this.handleFormView.hide();
    // }, error =>{
    //   console.log(error);
    // });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editCity', (e)=>{
            //let dataId = $(e.target).attr('data-id');
            this.editCity();
        })
    })
  }
 
  
}
