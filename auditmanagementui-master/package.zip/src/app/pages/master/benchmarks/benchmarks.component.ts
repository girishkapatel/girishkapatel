import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BenchmarksService } from './benchmarks.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-benchmarks',
  templateUrl: './benchmarks.component.html',
  styleUrls: ['./benchmarks.component.css'],
  providers:[BenchmarksService]
})
export class BenchmarksComponent implements OnInit{

  constructor(private benchmarks:BenchmarksService) { }
  
  @ViewChild('benchmarksForm', {static:false}) benchmarksForm:NgForm;

  tableId:string = "benchmarks_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Business Cycle',
    data:'bc'
  },{
    title:'L1 Process', 
    data:'pl1'
  },{
    title:'EY Benchmarks', 
    data:'pl1'
  },{
    title:'Bottom Performance (In INR)',
    data:'bp'
  },{
    title:'Median (In INR)',
    data:'md'
  },{
    title:'Top Performance (In INR)',
    data:'tp'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editBenchmarks"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    bc:'Procure to Pay',
    pl1:'Procurement',
    bm:'Total cost of the process "develop sourcing strategies" per INR 1,000 revenue',
    bp:'1000',
    md:'1000',
    tp:'1000'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveBenchmarks(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateBenchmarks();
    }else{
      this.addNewBenchmarks();
    }
  }

  addNewBenchmarks(){
    let postData = this.benchmarksForm.form.value;
    console.log(postData);
    this.benchmarks.addBenchmarks('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateBenchmarks(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.benchmarks.updateBenchmarks('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addBenchmarks(){
    this.handleFormView.show();
  }

  editBenchmarks(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteBenchmarks(){
    this.benchmarks.deleteBenchmarks('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editBenchmarks', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editBenchmarks();
        })
    })
  }
 
  
}
