import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { RisksService } from './risks.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-risks',
  templateUrl: './risks.component.html',
  styleUrls: ['./risks.component.css'],
  providers:[RisksService]
})
export class RisksComponent implements OnInit{

  constructor(private risks:RisksService) { }
  
  @ViewChild('risksForm', {static:false}) risksForm:NgForm;

  tableId:string = "risks_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Risk Title',
    data:'name'
  },{
    title:'Description',
    data:'desc'
  },{
    title:'Risk ID',
    data:'riskid'
  },{
    title:'Risk Rating',
    data:'rating'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editRisks"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Duplicate booking of invoices',
    desc:'Duplicate booking of invoices resulting due to lack of system restriction resulting into double payments ',
    riskid:'PTP. R.01',
    rating:'High'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveRisks(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateRisks();
    }else{
      this.addNewRisks();
    }
  }

  addNewRisks(){
    let postData = this.risksForm.form.value;
    console.log(postData);
    this.risks.addRisks('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateRisks(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.risks.updateRisks('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addRisks(){
    this.handleFormView.show();
  }

  editRisks(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteRisks(){
    this.risks.deleteRisks('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editRisks', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editRisks();
        })
    })
  }
 
  
}
