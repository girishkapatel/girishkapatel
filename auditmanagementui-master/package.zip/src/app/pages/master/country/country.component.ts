import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { CountryService } from './country.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit{

  constructor(private country:CountryService) { }
  
  @ViewChild('countryForm', {static:false}) countryForm:NgForm;

  tableId:string = "country_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Name',
    data:'name'
  },{
    title:'Status',
    data:'status'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editCountry"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'India',
    status:'Active'
  },{
    id:2,
    name:'USA',
    status:'Active'
  },{
    id:3,
    name:'UK',
    status:'Active'
  },{
    id:4,
    name:'Africa',
    status:'Active'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveCountry(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateCountry();
    }else{
      this.addNewCountry();
    }
  }

  addNewCountry(){
    let postData = this.countryForm.form.value;
    console.log(postData);
    this.country.addCountry('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateCountry(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.country.updateCountry('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addCountry(){
    this.handleFormView.show();
  }

  editCountry(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteCountry(){
    this.country.deleteCountry('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editCountry', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editCountry();
        })
    })
  }
 
  
}
