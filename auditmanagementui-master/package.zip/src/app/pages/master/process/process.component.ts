import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { ProcessService } from './process.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-process',
  templateUrl: './process.component.html',
  styleUrls: ['./process.component.css'],
  providers:[ProcessService]
})
export class ProcessComponent implements OnInit{

  constructor(private process:ProcessService) { }
  
  @ViewChild('processForm', {static:false}) processForm:NgForm;

  tableId:string = "process_table";
  
  tableGetApi:string='posts';
  tableColumns:tableColumn[] = [{
    title:'Name',
    data:'name'
  },{
    title:'Parent Process',
    data:'parent'
  },{
    title:'Location',
    data:'location'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editProcess"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Procure To Pay',
    parent:'',
    location:'Mithapur'
  },{
    id:1,
    name:'Accounts Payable',
    parent:'Procure To Pay',
    location:''
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveProcess(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateProcess();
    }else{
      this.addNewProcess();
    }
  }

  addNewProcess(){
    let postData = this.processForm.form.value;
    console.log(postData);
    this.process.addProcess('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateProcess(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.process.updateProcess('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addProcess(){
    this.handleFormView.show();
  }

  editProcess(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteProcess(){
    this.process.deleteProcess('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editProcess', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editProcess();
        })
    })
  }
 
  
}
