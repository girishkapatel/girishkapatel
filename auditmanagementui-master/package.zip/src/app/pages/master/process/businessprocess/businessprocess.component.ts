import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-businessprocess',
  templateUrl: './businessprocess.component.html',
  providers:[]
})
export class BusinessProcessComponent implements OnInit{

  constructor() { }
  
  tableId:string = "process_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Name',
    data:'name'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editBusinessProcess"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Procure to Pay'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveBusinessProcess(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateBusinessProcess();
    }else{
      this.addNewBusinessProcess();
    }
  }

  addNewBusinessProcess(){
    
  }

  updateBusinessProcess(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addBusinessProcess(){
    this.handleFormView.show();
  }

  editBusinessProcess(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteBusinessProcess(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editBusinessProcess', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editBusinessProcess();
        })
    })
  }
 
  
}
