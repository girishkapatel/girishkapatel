import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-processlevel1',
  templateUrl: './processlevel1.component.html',
  providers:[]
})
export class ProcessLevel1Component implements OnInit{

  constructor() { }
  
  tableId:string = "process_1_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Business Cycle',
    data:'cycle'
  },{
    title:'Process L1',
    data:'name'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editL1"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    cycle:'Procure to Pay',
    name:'Accounts Payable'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveBusinessProcess(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateBusinessProcess();
    }else{
      this.addNewBusinessProcess();
    }
  }

  addNewBusinessProcess(){
    
  }

  updateBusinessProcess(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addBusinessProcess(){
    this.handleFormView.show();
  }

  editBusinessProcess(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteBusinessProcess(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editL1', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editBusinessProcess();
        })
    })
  }
 
  
}
