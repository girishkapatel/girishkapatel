import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-processlevel2',
  templateUrl: './processlevel2.component.html',
  providers:[]
})
export class ProcessLevel2Component implements OnInit{

  constructor() { }
  
  tableId:string = "process_2_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Business Cycle',
    data:'l1'
  },{
    title:'Process L1',
    data:'cycle'
  },{
    title:'Process L2',
    data:'name'
  },{
    title:'Process Model',
    data:'model'
  },{
    title:'Head Office',
    data:'',
    render:function(data) {
      return '<input type="checkbox" checked>';
    }
  },{
    title:'Mithapur',
    data:'',
    render:function(data) {
      return '<input type="checkbox" checked>';
    }
  },{
    title:'Babrala Plant',
    data:'',
    render:function(data) {
      return '<input type="checkbox" checked>';
    }
  },{
    title:'Nutra Plant',
    data:'',
    render:function(data) {
      return '<input type="checkbox" checked>';
    }
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editL2"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Accounts Payable Planning',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  },{
    id:2,
    name:'Vendor Management',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  },{
    id:3,
    name:'RFQ and Bidding Process',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  },{
    id:4,
    name:'Vendor Selection',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  },{
    id:5,
    name:'Ordering',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  },{
    id:5,
    name:'Post PO Activities',
    cycle:'Accounts Payable',
    l1:"Procure to Pay",
    model:"Decentralised"
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveBusinessProcess(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateBusinessProcess();
    }else{
      this.addNewBusinessProcess();
    }
  }

  addNewBusinessProcess(){
    
  }

  updateBusinessProcess(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addBusinessProcess(){
    this.handleFormView.show();
  }

  editBusinessProcess(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteBusinessProcess(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editL2', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editBusinessProcess();
        })
    })
  }
 
  
}
