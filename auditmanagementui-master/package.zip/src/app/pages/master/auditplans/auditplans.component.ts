import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { AuditPlanService } from './auditplans.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-auditplan',
  templateUrl: './auditplans.component.html',
  styleUrls: ['./auditplans.component.css'],
  providers:[AuditPlanService]
})
export class AuditPlanComponent implements OnInit{

  constructor(private auditplan:AuditPlanService) { }
  
  @ViewChild('auditplanForm', {static:false}) auditplanForm:NgForm;

  tableId:string = "auditplan_table";
  
  tableGetApi:string='posts';

  auditColumns:tableColumn[] = [{
        title:'Internal Audit Areas',
        data:'area'
        },{
            title:'Risk Categorisation',
            data:'riskcat',
            render:function(data) {
              let  colors = {
                    high:'#f04c3e',
                    medium:'#FFC200',
                    low:'#2c973e'
                  }
              return '<span style="padding: 3px 10px; color: #fff;background:'+colors[data.toLowerCase()]+'">'+data+'</span>';
            }
        },{
            title:'2020-21',
            data:'checked',
            render:(checked)=>{
              let isChecked = checked ? 'checked' : '';
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small" '+isChecked+'>';
            }
        },
        {
            title:'2021-22',
            data:'riskcat',
            render:(riskcat)=>{
               let isChecked = riskcat.toLowerCase() === 'medium' ? 'checked' : '';
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small" '+isChecked+'>';
            }
        }
        ,{
            title:'2022-23',
            data:'riskcat',
            render:(riskcat)=>{
              let isChecked = riskcat.toLowerCase() === 'high' ? 'checked' : '';
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small" '+isChecked+'>';
            }
        }
    ]

    auditMapData:tableData[]=[
        {area:"Accounts Payable",riskcat:"High", checked:true},
        {area:"Sales and Marketing",riskcat:"High", checked:true},
        {area:"Logistics",riskcat:"High", checked:true},
        {area:"Plant Maintenance (Asset Care Management)",riskcat:"High"},
        {area:"Salt packing Centre (SPC)",riskcat:"High", checked:true},
        {area:"Safety, Health & Environment",riskcat:"High", checked:true},
        {area:"Compliances",riskcat:"High", checked:true},
        {area:"Capex",riskcat:"High", checked:true},
        {area:"Plant Operations review",riskcat:"High", checked:true},
        {area:"Related Party Transactions ( Half Yearly)",riskcat:"High"},
        {area:"SAP Control Review(All Modules)",riskcat:"High"},
        {area:"IT Controls Review Genral Controls",riskcat:"High"},
        {area:"IT Cyber Security",riskcat:"High", checked:true},
        {area:"IT  Data privacy ",riskcat:"High", checked:true},
        {area:"Outsourced Salt operations ",riskcat:"Medium"},
        {area:"Disaster Recovery Planning (Potential Natural and Security Risk)",riskcat:"Medium"},
        {area:"Internal Financial Control",riskcat:"Medium"}

    ]

  tableColumns:tableColumn[] = [{
    title:'Name',
    data:'name'
  },{
    title:'Location',
    data:'location'
  },{
    title:'Criticality',
    data:'criticality'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editAuditPlan"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    name:'Tata Chemical Limited',
    location:'Mithapur',
    criticality:'High'
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveAuditPlan(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateAuditPlan();
    }else{
      this.addNewAuditPlan();
    }
  }

  addNewAuditPlan(){
    let postData = this.auditplanForm.form.value;
    console.log(postData);
    this.auditplan.addAuditPlan('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateAuditPlan(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.auditplan.updateAuditPlan('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addAuditPlan(){
    this.handleFormView.show();
  }

  editAuditPlan(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteAuditPlan(){
    this.auditplan.deleteAuditPlan('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editAuditPlan', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editAuditPlan();
        })
    })
  }
 
  
}
