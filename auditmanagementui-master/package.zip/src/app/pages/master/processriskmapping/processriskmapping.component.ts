import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { ProcessriskmappingService } from './processriskmapping.service';
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-processriskmapping',
  templateUrl: './processriskmapping.component.html',
  styleUrls: ['./processriskmapping.component.css'],
  providers:[ProcessriskmappingService]
})
export class ProcessriskmappingComponent implements OnInit{

  constructor(private processriskmapping:ProcessriskmappingService) { }
  
  @ViewChild('processriskmappingForm', {static:false}) processriskmappingForm:NgForm;

  tableId:string = "processriskmapping_table";
  
  tableGetApi:string='posts';
  
    tableColumns:tableColumn[] = [{
    title:"Process L1",
    data:"process"
  },{
    title:"Reporting Materiality",
    data:"rm"
  },
  {
    title:"Key ERM Risks Identified",
    data:"risks"
  },
  {
    title:"Key BI Identified",
    data:"bi"
  },
  {
    title:"Fraud Vulnerability",
    data:"fraud"
  },
  // {
  //   title:"Complexity / volume of transactions",
  //   data:"complexity"
  // },
  // {
  //   title:"Past Audit Results - Control weakness", 	
  //   data:"pcw"
  // },
  {
    title:"Process Risk Rating",
    data:"prr"
  },
  // {
  //   title:"Locations",
  //   data:"location"
  // },
  {
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editProcessriskmapping"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    process:'Accounts Payable',
    rm:"High",
    risks:"Medium",
    bi:"Low",
    fraud:"Medium",
    complexity:"Low",
    //pcw:"3",
    prr:"High"
    // ,
    // location:"Mithapur"
  },{
    process:'Accounts Payable',
    rm:"High",
    risks:"Low",
    bi:"Low",
    fraud:"High",
    complexity:"Low",
    //pcw:"3",
    prr:"High"
    // ,
    // location:"Mithapur"
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveProcessriskmapping(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateProcessriskmapping();
    }else{
      this.addNewProcessriskmapping();
    }
  }

  addNewProcessriskmapping(){
    let postData = this.processriskmappingForm.form.value;
    console.log(postData);
    this.processriskmapping.addProcessriskmapping('posts', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  updateProcessriskmapping(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }

    this.processriskmapping.updateProcessriskmapping('posts/1', postData).subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  addProcessriskmapping(){
    this.handleFormView.show();
  }

  editProcessriskmapping(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteProcessriskmapping(){
    this.processriskmapping.deleteProcessriskmapping('post/1').subscribe(response=>{
      console.log(response);
      this.handleFormView.hide();
    }, error =>{
      console.log(error);
    });
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editProcessriskmapping', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editProcessriskmapping();
        })
    })
  }
 
  
}
