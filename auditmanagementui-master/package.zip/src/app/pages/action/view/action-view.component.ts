import { Component, OnInit } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import {Router} from "@angular/router";
import * as $ from 'jquery';

@Component({
    selector: 'selector',
    templateUrl: 'action-view.component.html'
})
export class ActionViewComponent implements OnInit {

    constructor(private router:Router) { }

    tableColumnsAP:tableColumn[] = [{
      title:'Audit',
      data:'Audit'
    },{
      title:'Location',
      data:'Location'
    },{
      title:'Action Plan',
      data:'Action'
    },{
      title:'Related Observation',
      data:'Related'
    },{
      title:'Responsible',
      data:'Responsible'
    },{
      title:'Due Date',
      data:'Due'
    },{
      title:'Owner Status',
      data:'Owner'
    },{
      title:'Approver Status',
      data:'Approver'
    },{
      title:'Auditor Status',
      data:'Auditor'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          let aHtml = '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green editAction"><i class="fa fa-view"></i> View </a>';
          return aHtml;
      }
    }
  ]

  tableData_ap:tableData[]=[{
    "id":1,
    "Audit":"Audit",
    "Location":"Location",
    "Action":"Action Plan",
    'Related':'Related Observation',
    'Responsible':'Responsible',
    'Due':'Due Date',
    'Owner':'Owner Status',
    'Approver':'Approver Status',
    'Auditor':'Auditor Status'
  }]
  
    tableFilters = new BehaviorSubject({});
    ngOnInit() { 
        $(document).ready(()=>{
            $('body').on('click', '.editAction', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.editAction();
            })
        })
    }

    editAction(){
        this.router.navigate(['./pages/action/edit']);
    }

    addAction(){
        this.router.navigate(['./pages/action/add']);
    }

}