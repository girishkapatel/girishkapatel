import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActionComponent } from "./action.component";
import { ActionAddComponent } from "./add/action-add.component";
import { ActionEditComponent } from "./edit/action-edit.component";
import { ActionViewComponent } from "./view/action-view.component";
import { ActionRoutingModule } from './action-routing.module';
import { TableModule } from "../../common/table/table.module";

@NgModule({
    imports: [
        ActionRoutingModule,
        TableModule,
        CommonModule        
    ],
    declarations: [
        ActionComponent,
        ActionEditComponent,
        ActionAddComponent,
        ActionViewComponent
    ]
})

export class ActionModule {}