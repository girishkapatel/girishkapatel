import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router"
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery';
@Component({
    selector: 'selector',
    templateUrl: 'action-edit.component.html',
    styleUrls: ['./action-edit.component.css']
})
export class ActionEditComponent implements OnInit {

    constructor(private router:Router) { }

    formVisible:boolean = false;
    
    ngOnInit() { 
        $(document).ready(()=>{
            $("body").on("click", ".viewAuditStep", ()=>{
                this.addControl();
            })
        })
    }

    addControl(){
        this.formVisible = true;
    }

    cancelControlAddEdit(){
        this.formVisible = false;
    }

    backToActionView(){
        this.router.navigate(['./pages/action']);
    }

}