import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from "./dashboard.component";
import { ChartsModule } from "../../common/charts/charts.module";
import { TableModule } from "../../common/table/table.module";
import { DashboardRoutingModule } from './dashboard-routing.module';

@NgModule({
    imports: [
        DashboardRoutingModule,
        CommonModule,
        ChartsModule,
        TableModule        
    ],
    declarations: [
        DashboardComponent
    ]
})

export class DashboardModule {}