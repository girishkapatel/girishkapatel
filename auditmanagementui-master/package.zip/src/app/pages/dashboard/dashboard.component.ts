import { Component, NgZone, OnInit, AfterViewInit, OnDestroy, ViewChild, ElementRef} from '@angular/core';
import * as am4charts from "@amcharts/amcharts4/charts";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4maps from "@amcharts/amcharts4/maps";
import { tableColumn, tableData } from './../../common/table/table.model'
import am4geodata_worldLow from "../../common/data/worldLow.data";
import am4geodata_data_countries2 from "../../common/data/countries2.data";

import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as $ from 'jquery';
import {Router} from '@angular/router'

am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  
  constructor(private router:Router) { }
  @ViewChild('dataDiv', {static:false}) dataDiv: ElementRef;
  tableTitle:string = 'Overall Audits';
  colorSet = new am4core.ColorSet();
  showDetails:boolean = false;
  worldchart:any;
  locationDD:any[] = [
    'Pune-India',
    'Houston-USA',
    'Mumbai HO-India',
    'London-UK',
    'jamshedpur-India',
    'Paris-France',
    'Mumbai HO-India',
    'Houston-USA',
    'Pune-India',
    'Rome-Italy'
  ]
  byDivision:any[] = [
    {
      division:"Chemicals",
      plan:"14",
      completed:"8",
      delay:"5",
      data:"6",
      risk:"23",
      repeat:"22",
      flags:"2",
      defaults:"42",
      controls:"105",
      gaps:"95",
      past2:"125",
      auditcompleted:"75",
      auditdelayed:"7",
      auditCompWithDelay:"18",
      saving:"215",
      enhance:"34",
      leading:"4"
    },
    {
      division:"Bio-carbs",
      plan:"7",
      completed:"1",
      delay:"1",
      data:"6",
      risk:"7",
      repeat:"18",
      flags:"1",
      defaults:"8",
      controls:"25",
      gaps:"15",
      past2:"35",
      auditcompleted:"15",
      auditdelayed:"2",
      auditCompWithDelay:"8",
      saving:"85",
      enhance:"15",
      leading:"1"
    },
    {
      division:"Cement",
      plan:"5",
      completed:"1",
      delay:"1",
      data:"4",
      risk:"3",
      repeat:"12",
      flags:"0",
      defaults:"2",
      controls:"15",
      gaps:"10",
      past2:"10",
      auditcompleted:"12",
      auditdelayed:"0",
      auditCompWithDelay:"5",
      saving:"10",
      enhance:"5",
      leading:"0"
    },
    {
      division:"Total",
      plan:"26",
      completed:"10",
      delay:"7",
      data:"16",
      risk:"33",
      repeat:"52",
      flags:"3",
      defaults:"52",
      controls:"145",
      gaps:"120",
      past2:"170",
      auditcompleted:"102",
      auditdelayed:"9",
      auditCompWithDelay:"31",
      saving:"310",
      enhance:"54",
      leading:"5"
    }
  ]
  
  byProcess:any[] = [{process:'Asset Management',risk:'2',repeat:'7',flags:'',default:'',control:'15',gaps:'8',past2:'12',auditcompleted:'10',auditdelayed:'',auditCompWithDelay:'2',saving:'',enhance:'5',leading:'18'},
{process:'Business review',risk:'5',repeat:'6',flags:'',default:'',control:'14',gaps:'12',past2:'17',auditcompleted:'12',auditdelayed:'1',auditCompWithDelay:'4',saving:'20',enhance:'6',leading:'18'},
{process:'HR & Payroll',risk:'3',repeat:'8',flags:'1',default:'11',control:'16',gaps:'14',past2:'19',auditcompleted:'16',auditdelayed:'1',auditCompWithDelay:'5',saving:'80',enhance:'5',leading:'18'},
{process:'IT data security',risk:'3',repeat:'3',flags:'',default:'4',control:'12',gaps:'11',past2:'14',auditcompleted:'7',auditdelayed:'1',auditCompWithDelay:'1',saving:'',enhance:'11',leading:'18'},
{process:'Legal compliance',risk:'8',repeat:'11',flags:'',default:'28',control:'11',gaps:'16',past2:'18',auditcompleted:'8',auditdelayed:'',auditCompWithDelay:'1',saving:'',enhance:'1',leading:'18'},
{process:'Marketing review',risk:'1',repeat:'6',flags:'1',default:'',control:'8',gaps:'4',past2:'12',auditcompleted:'2',auditdelayed:'1',auditCompWithDelay:'1',saving:'',enhance:'2',leading:'18'},
{process:'Order to Cash',risk:'3',repeat:'3',flags:'',default:'',control:'26',gaps:'23',past2:'32',auditcompleted:'22',auditdelayed:'2',auditCompWithDelay:'7',saving:'120',enhance:'11',leading:'18'},
{process:'Plant operations',risk:'3',repeat:'2',flags:'',default:'6',control:'10',gaps:'6',past2:'18',auditcompleted:'7',auditdelayed:'',auditCompWithDelay:'2',saving:'',enhance:'2',leading:'18'},
{process:'Procure to Pay',risk:'4',repeat:'6',flags:'1',default:'3',control:'27',gaps:'22',past2:'28',auditcompleted:'18',auditdelayed:'3',auditCompWithDelay:'8',saving:'90',enhance:'6',leading:'18'},
{process:'Social media review',risk:'1',repeat:'',flags:'',default:'',control:'6',gaps:'4',past2:'',auditcompleted:'',auditdelayed:'',auditCompWithDelay:'',saving:'',enhance:'5',leading:'18'},
{process:'Total',risk:'33',repeat:'52',flags:'3',default:'52',control:'145',gaps:'120',past2:'170',auditcompleted:'102',auditdelayed:'9',auditCompWithDelay:'31',saving:'310',enhance:'54',leading:'18'}]

byLocation:any[] = [{location:'Pune-India',audit:'Asset Management',year:'2019-20',status:'Completed',inforating:'2',punctuality:'1',auditrating:'',processhealth:'',obs:'2',flags:'',repeat:'7',total:'10',closed:'83.3333333333333'},
{location:'Houston-USA',audit:'Business review',year:'2019-20',status:'Completed',inforating:'2',punctuality:'2',auditrating:'',processhealth:'',obs:'5',flags:'',repeat:'6',total:'12',closed:'70.5882352941177'},
{location:'Mumbai HO-India',audit:'HR & Payroll',year:'2019-20',status:'Completed',inforating:'1',punctuality:'1',auditrating:'',processhealth:'',obs:'3',flags:'1',repeat:'8',total:'16',closed:'84.2105263157895'},
{location:'London-UK',audit:'IT data security',year:'2019-20',status:'Completed',inforating:'3',punctuality:'3',auditrating:'',processhealth:'',obs:'3',flags:'',repeat:'3',total:'7',closed:'50'},
{location:'jamshedpur-India',audit:'Legal compliance',year:'2019-20',status:'Completed',inforating:'1',punctuality:'1',auditrating:'',processhealth:'',obs:'8',flags:'',repeat:'11',total:'8',closed:'44.4444444444444'},
{location:'Paris-France',audit:'Marketing review',year:'2019-20',status:'Completed',inforating:'1',punctuality:'1',auditrating:'',processhealth:'',obs:'1',flags:'1',repeat:'6',total:'2',closed:'16.6666666666667'},
{location:'Mumbai HO-India',audit:'Order to Cash',year:'2019-20',status:'Completed',inforating:'3',punctuality:'2',auditrating:'',processhealth:'',obs:'3',flags:'',repeat:'3',total:'22',closed:'68.75'},
{location:'Houston-USA',audit:'Plant operations',year:'2019-20',status:'Completed',inforating:'5',punctuality:'4',auditrating:'',processhealth:'',obs:'3',flags:'',repeat:'2',total:'7',closed:'38.8888888888889'},
{location:'Pune-India',audit:'Procure to Pay',year:'2019-20',status:'Completed',inforating:'3',punctuality:'2',auditrating:'',processhealth:'',obs:'4',flags:'1',repeat:'6',total:'18',closed:'64.2857142857143'},
{location:'Rome-Italy',audit:'Social media review',year:'2019-20',status:'Completed',inforating:'5',punctuality:'4',auditrating:'',processhealth:'',obs:'1',flags:'',repeat:'',total:'',closed:''},
{location:'Total',audit:'',year:'',status:'',inforating:'',punctuality:'',auditrating:'',processhealth:'',obs:'33',flags:'3',repeat:'52',total:'102',closed:''}]

  imsDataIndex1:any[] = ["India", "United Kingdom", "Spain"];
  imsDataIndex2:any[] = ["Denmark", "France", "Russia"];
  imsDataIndex3:any[] = ["United States", "Canada", "Japan"];
  imsDataIndex:any[] = [...this.imsDataIndex1, ...this.imsDataIndex2,...this.imsDataIndex1];
  
  highRiskColor:string = "#f04c3e";
  mediumRiskColor:string = "#FFC200";
  lowRiskColor:string = "#2c973e";

  auditDataMap1:any[] = [{
      "id": "IN",
      "name": "India",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.highRiskColor)
    }, {
      "id": "GB",
      "name": "United Kingdom",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.highRiskColor)
    }, {
      "id": "ES",
      "name": "Spain",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.highRiskColor)
    }] 
  auditDataMap2:any[] = [{
      "id": "DK",
      "name": "Denmark",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.mediumRiskColor)
    }, {
      "id": "FR",
      "name": "France",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.mediumRiskColor)
    }, {
      "id": "RU",
      "name": "Russia",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.mediumRiskColor)
    }];
    
  auditDataMap3:any[] = [{
      "id": "US",
      "name": "United States",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.lowRiskColor)
    }, {
      "id": "CA",
      "name": "Canada",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.lowRiskColor)
    }, {
      "id": "JP",
      "name": "Japan",
      "title":"(High : 10, Medium: 10, Low : 10)",
      "fill": am4core.color(this.lowRiskColor)
    }];

  auditDataMap:any[]= [...this.auditDataMap1, ...this.auditDataMap2, ...this.auditDataMap3];


  BusinessUnitTitle:string = 'Overall';
  critcalityTitle:string = 'Overall';
  CompanyTitle:string = '';

  BusinessUnit2 = [{
      "title": "Copenhagen",
      "latitude": 55.6763,
      "longitude": 12.5681,
      "color":this.colorSet.next()
    }, {
      "title": "Paris",
      "latitude": 48.8567,
      "longitude": 2.3510,
      "color":this.colorSet.next()
    }, {
      "title": "Moscow",
      "latitude": 55.7558,
      "longitude": 37.6176,
      "color":this.colorSet.next()
    }];

    BusinessUnit1 = [{
      "title": "Madrid",
      "latitude": 40.4167,
      "longitude": -3.7033,
      "color":this.colorSet.next()
    }, {
      "title": "London",
      "latitude": 51.5002,
      "longitude": -0.1262,
      "color":this.colorSet.next()
    }, {
      "title": "New Delhi",
      "latitude": 28.6353,
      "longitude": 77.2250,
      "color":this.colorSet.next()
    }];

    BusinessUnit3 = [{
      "title": "Tokyo",
      "latitude": 35.6785,
      "longitude": 139.6823,
      "color":this.colorSet.next()
    }, {
      "title": "Ottawa",
      "latitude": 45.4235,
      "longitude": -75.6979,
      "color":this.colorSet.next()
    }, {
      "title": "Washington",
      "latitude": 38.8921,
      "longitude": -77.0241,
      "color":this.colorSet.next()
    }];

  tableColumns:tableColumn[] = [{
      title:'Audit Name',
      data:'name'
    },{
      title:'Status',
      data:'status'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          return '<a data-id="'+data+'" id="'+row.status + data+'" class="btn btn-sm yellow viewAudit"><i class="fa fa-eye"></i> View </a>';
      }
    }
  ]

  tableData_ongoing:tableData[]=[{
    id:1,
    name:"Procure To Pay",
    status:"In-Progress"
  },{
    id:2,
    name:"Compliances",
    status:"In-Progress"
  },{
    id:3,
    name:"IT Data privacy",
    status:"Pending Initiation"
  },{
    id:1,
    name:"IT Cyber Security",
    status:"Pending Initiation"
  },{
    id:1,
    name:"Logistics",
    status:"In-Progress"
  },{
    id:1,
    name:"Plant Operations review",
    status:"Completed"
  },{
    id:1,
    name:"Capex",
    status:"Completed"
  },
  {
    id:1,
    name:"Safety, Health & Environment",
    status:"Completed"
  },
  {
    id:1,
    name:"Sales and Marketing",
    status:"Completed"
  },{
    id:1,
    name:"Salt packing Centre (SPC)",
    status:"Completed"
  }]
  
  
  ngAfterViewInit(){
    this.initWorldMap([...this.BusinessUnit1, ...this.BusinessUnit2, ...this.BusinessUnit3]);
  }

  scroll(tableTitle:string) {
      this.tableTitle = tableTitle;
      setTimeout(() => {
        this.dataDiv.nativeElement.scrollIntoView();
      }, 300);
      
  }

  showBusinessUnit(title:string, bdata:string){
    this.BusinessUnitTitle = bdata;
    if(this.BusinessUnitTitle === 'Overall' && this.CompanyTitle === 'Overall'){
      this.CompanyTitle = '';
    }
    switch (title) {
      case 'Overall':
        this.imsDataIndex = [...this.imsDataIndex1, ...this.imsDataIndex2,...this.imsDataIndex1];
        this.auditDataMap = [...this.auditDataMap1, ...this.auditDataMap2, ...this.auditDataMap3];
        this.initWorldMap([...this.BusinessUnit1, ...this.BusinessUnit2, ...this.BusinessUnit3]);
        break;
      case 'Business Unit 1':
        this.imsDataIndex = this.imsDataIndex1;
        this.auditDataMap = this.auditDataMap1;
        this.initWorldMap(this.BusinessUnit1);
        break;
      case 'Business Unit 2':
      this.imsDataIndex = this.imsDataIndex2;
      this.auditDataMap = this.auditDataMap2;
        this.initWorldMap(this.BusinessUnit2);
        break;
      case 'Business Unit 3':
      this.imsDataIndex = this.imsDataIndex3;
      this.auditDataMap = this.auditDataMap3;
        this.initWorldMap(this.BusinessUnit3);
        break;
    }
  }

  showCriticality(title:string){
    this.critcalityTitle = title;
    
    switch (title) {
      case 'Overall':
        this.showBusinessUnit('Overall', this.BusinessUnitTitle);
        break;
      case 'High':
        this.showBusinessUnit('Business Unit 1', this.BusinessUnitTitle)
        break;
      case 'Medium':
        this.showBusinessUnit('Business Unit 2', this.BusinessUnitTitle)
        break;
      case 'Low':
        this.showBusinessUnit('Business Unit 3', this.BusinessUnitTitle)
        break;
    }
  }

  showCompanyData(title:string, cdata:string){
    if(this.BusinessUnitTitle === 'Overall'){
      this.CompanyTitle = '';
    }else{
      this.CompanyTitle = cdata;
    }
    
    switch (title) {
      case 'Overall':
        if(this.BusinessUnitTitle === 'Overall'){
          this.imsDataIndex = [...this.imsDataIndex1, ...this.imsDataIndex2, , ...this.imsDataIndex3];
          this.auditDataMap = [...this.auditDataMap1, ...this.auditDataMap2, ...this.auditDataMap3];
          this.initWorldMap([...this.BusinessUnit1, ...this.BusinessUnit2, ...this.BusinessUnit2]);
        }else{
          this.imsDataIndex = [...this.imsDataIndex1, ...this.imsDataIndex2];
          this.auditDataMap = [...this.auditDataMap1, ...this.auditDataMap2];
          this.initWorldMap([...this.BusinessUnit1, ...this.BusinessUnit2]);
        }
        break;
      case 'Company 1':
        this.imsDataIndex = this.imsDataIndex2;
        this.auditDataMap = this.auditDataMap2;
        this.initWorldMap(this.BusinessUnit2);
        break;
      case 'Company 2':
      this.imsDataIndex = this.imsDataIndex3;
      this.auditDataMap = this.auditDataMap3;
        this.initWorldMap(this.BusinessUnit3);
        break;
      case 'Company 3':
      this.imsDataIndex = this.imsDataIndex1;
      this.auditDataMap = this.auditDataMap1;
        this.initWorldMap(this.BusinessUnit1);
        break;
    }
  }

  showDetailStats(dataItem:any){
    this.showDetails = true;
  }

  showMap(){
    this.showDetails = false;
  }

  updateCustomMarkers(imageSeries){
      
      // go through all of the images
      if(imageSeries && imageSeries.mapImages){
        imageSeries.mapImages.each((image)=> {
          // check if it has corresponding HTML element
          if (!image.dummyData || !image.dummyData.externalElement) {
            // create onex
            image.dummyData = {
              externalElement: this.createCustomMarker(image)
            };
          }

          // reposition the element accoridng to coordinates
          let xy = this.worldchart.geoPointToSVG( { longitude: image.longitude, latitude: image.latitude } );
          image.dummyData.externalElement.style.top = xy.y + 'px';
          image.dummyData.externalElement.style.left = xy.x + 'px';
        });
      }

  }

  createCustomMarker(image){
    
    let ichart = image.dataItem.component.chart;

    // create holder
    let holder = document.createElement( 'div' );
    holder.className = 'map-marker';
    holder.title = image.dataItem.dataContext.title;
    holder.style.position = 'absolute';

    // maybe add a link to it?
    if ( undefined != image.url ) {
      holder.onclick = function() {
        window.location.href = image.url;
      };
      holder.className += ' map-clickable';
    }

    // create dot
    let dot = document.createElement( 'div' );
    dot.className = 'dot';
    holder.appendChild( dot );

    // create pulse
    let pulse = document.createElement( 'div' );
    pulse.className = 'pulse';
    holder.appendChild( pulse );

    // append the marker to the map container
    ichart.svgContainer.htmlElement.appendChild( holder );

    return holder;
  }

  initWorldMap(worldchartData:any){
    // Create map instance
    if(this.worldchart){
      this.worldchart.dispose();
    }
    this.worldchart = am4core.create("vmap_world", am4maps.MapChart);
    this.worldchart.maxZoomLevel = 1;
    this.worldchart.seriesContainer.draggable = false;
    this.worldchart.seriesContainer.resizable = false;
    // Set map definition
    this.worldchart.geodata = am4geodata_worldLow;

    // Set projection
    this.worldchart.projection = new am4maps.projections.Miller();
    
    let legend = new am4charts.Legend();
    legend.parent = this.worldchart.chartContainer;
    legend.background.fill = am4core.color("#000");
    legend.background.fillOpacity = 0.05;
    legend.width = 120;
    legend.align = "right";
    legend.valign = "bottom";
    legend.dy = -50;
    legend.data = [{
      "name": "High",
      "fill":this.highRiskColor
    }, {
      "name": "Medium",
      "fill": this.mediumRiskColor
    }, {
      "name": "Low",
      "fill": this.lowRiskColor
    }];
    legend.events.on("hit", (e)=>{
        console.log(e.target);
    })

    legend.itemContainers.template.clickable = false;
    legend.itemContainers.template.focusable = false;
      
    // Create map polygon series
    let polygonSeries = this.worldchart.series.push(new am4maps.MapPolygonSeries());
    
    // Exclude Antartica
    polygonSeries.exclude = ["AQ"];

    // Make map load polygon (like country names) data from GeoJSON
    polygonSeries.useGeodata = true;
    
    polygonSeries.data = this.auditDataMap;     
    
    // Configure series
    let polygonTemplate = polygonSeries.mapPolygons.template;
    polygonTemplate.tooltipText = "{name}  {title}";

    let newColor = new am4core.ColorSet();
    newColor.baseColor = new am4core.Color({r:46,g:46,b:56})
    polygonTemplate.fill = newColor.getIndex(0).lighten(0.3);
    polygonTemplate.propertyFields.fill = "fill";
    // Create hover state and set alternative fill color
    //let hs = polygonTemplate.states.create("hover");
    //hs.properties.fill = this.worldchart.colors.getIndex(0);

    // Add image series
    let imageSeries = this.worldchart.series.push(new am4maps.MapImageSeries());
    imageSeries.mapImages.template.propertyFields.longitude = "longitude";
    imageSeries.mapImages.template.propertyFields.latitude = "latitude";
    imageSeries.data = worldchartData;

    // add events to recalculate map position when the map is moved or zoomed
    this.worldchart.events.on( "ready", this.updateCustomMarkers );
    this.worldchart.events.on( "mappositionchanged", ()=>{
      this.updateCustomMarkers(imageSeries)
    }); 

    polygonTemplate.events.on("hit", (e) => {
      let dataItem = e.target.dataItem.dataContext;
      console.log(dataItem);
      if(dataItem["name"] && this.imsDataIndex.indexOf(dataItem["name"]) > -1){
        this.showDetailStats(dataItem);
      }
      
    })
    
  }

  ngOnInit(){
    $(document).ready(()=>{
      $('body').on('click', '.viewAudit', ()=>{
        this.viewAudit();
      })

      $('#quickview .scroller').css('max-height', $('.page-content').height() - 50);

      // let tableConfig = {
      //   "scroll": true
      // }
      // $('#table1').DataTable();
    })
  }
  ngOnDestroy(){
    if(this.worldchart){
      this.worldchart.dispose();
    }
  }

  viewAudit(){
    this.router.navigate(['./pages/manageaudits/edit'])
  }  
}
