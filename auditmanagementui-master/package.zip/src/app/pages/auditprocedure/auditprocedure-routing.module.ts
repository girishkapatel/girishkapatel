import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuditProcedureComponent } from './auditProcedure.component';
import { AuditProcedureAddComponent } from "./add/auditProcedure-add.component";
import { AuditProcedureEditComponent } from "./edit/auditProcedure-edit.component";
import { AuditProcedureViewComponent } from "./view/auditProcedure-view.component";

const routes: Routes = [
  {
    path: '',
    component: AuditProcedureComponent,
    data: {
      title: 'Audit Procedure'
    },
    children:[
      {
        path: '',
        component: AuditProcedureViewComponent
      },
      {
        path: 'add',
        component: AuditProcedureAddComponent
      },
      {
        path: 'edit',
        component: AuditProcedureEditComponent
      }  
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AuditProcedureRoutingModule {}