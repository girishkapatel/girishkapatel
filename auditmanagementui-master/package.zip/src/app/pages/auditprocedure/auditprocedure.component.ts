import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auditprocedure',
  templateUrl: './auditprocedure.component.html',
  styleUrls: ['./auditprocedure.component.css']
})
export class AuditProcedureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
