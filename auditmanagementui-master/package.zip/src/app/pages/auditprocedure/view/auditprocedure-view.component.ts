import { Component, OnInit } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import {Router} from "@angular/router";
import * as $ from 'jquery';

@Component({
    selector: 'selector',
    templateUrl: 'auditprocedure-view.component.html'
})
export class AuditProcedureViewComponent implements OnInit {

    constructor(private router:Router) { }

    tableColumnsAP:tableColumn[] = [{
      title:'Procedure ID',
      data:'pid'
    },{
      title:'Procedure Title',
      data:'ptitle'
    },{
      title:'Business Cycle',
      data:'process'
    },{
      title:'Process L1',
      data:'l1'
    },{
      title:'Process L2',
      data:'l2'
    },{
      title:'Risk Title',
      data:'risk'
    },{
      title:'Company',
      data:'company'
    },{
      title:'Division',
      data:'division'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          let aHtml = '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm red editAuditProcedure"><i class="fa fa-edit"></i> Edit </a>';

          if(row.status === 'Inactive'){
            aHtml += '<a data-id="'+data+'" href="javascript:void(0);" class="btn btn-sm green initiateActivity"><i class="fa fa-edit"></i> Initiate </a>';
          }

          return aHtml;
      }
    }
  ]

  tableData_ap:tableData[]=[{
    id:1,
    pid:"PTP.P.01",
    ptitle:"Negative testing of system restriction",
    controlid:"PTP.C.01",
    control:"System restriction to process duplicate payment",
    process:"Procure To Pay",
    l1:"Accounts Payable",
    l2:"Invoice processing",
    risk:"Duplicate booking of invoices",
    status:"Active",
    company:"Tata Chemical Limited",
    division:"Chemical"
  }]
  
    tableFilters = new BehaviorSubject({});
    ngOnInit() { 
        $(document).ready(()=>{
            $('body').on('click', '.editAuditProcedure', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.editAuditProcedure();
            })
        })
    }

    editAuditProcedure(){
        this.router.navigate(['./pages/auditprocedure/edit']);
    }

    addAuditProcedure(){
        this.router.navigate(['./pages/auditprocedure/add']);
    }

}