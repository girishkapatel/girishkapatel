import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditProcedureComponent } from "./auditProcedure.component";
import { AuditProcedureAddComponent } from "./add/auditProcedure-add.component";
import { AuditProcedureEditComponent } from "./edit/auditProcedure-edit.component";
import { AuditProcedureViewComponent } from "./view/auditProcedure-view.component";
import { AuditProcedureRoutingModule } from './auditProcedure-routing.module';
import { TableModule } from "../../common/table/table.module";

@NgModule({
    imports: [
        AuditProcedureRoutingModule,
        TableModule,
        CommonModule        
    ],
    declarations: [
        AuditProcedureComponent,
        AuditProcedureEditComponent,
        AuditProcedureAddComponent,
        AuditProcedureViewComponent
    ]
})

export class AuditProcedureModule {}