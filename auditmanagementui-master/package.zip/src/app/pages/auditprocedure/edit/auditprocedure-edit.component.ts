import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router"
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery';
@Component({
    selector: 'selector',
    templateUrl: 'auditprocedure-edit.component.html'
})
export class AuditProcedureEditComponent implements OnInit {

    constructor(private router:Router) { }

    formVisible:boolean = false;
    
      tableColumns:tableColumn[] = [{
        title:'Control ID',
        data:'controlid'
        },{
        title:'Control Title',
        data:'control'
        },{
            title:'Audit Step',
            data:'astep'
        },{
            title:'Data Required',
            data:'dreq'
        },{
            title:'Data Period',
            data:'date'
        }
        ,{
            title:'Analytics Reference',
            data:'ref'
        },{
            title:'Data Source',
            data:'source'
        },{
            title:'Days Required',
            data:'days'
        },{
            title:'Performed By',
            data:'resource'
        },{
            title:'Action',
            data:'id',
            render:(data)=>{
                return '<p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm green viewAuditStep"><i class="fa fa-eye"></i> View </a></p> <p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red deleteAuditStep"><i class="fa fa-close"></i> Delete &nbsp;&nbsp; </a></p>';
                
            }
        }]

        tableData:tableData[] = [{
            controlid:"PTP.C.01",
            control:"System restriction to process duplicate payment",
            astep:"Perform process walkthrough of invoice processing and perform negative testing of duplicate invoice processing",
            dreq:"Screen shot of duplicate payment",
            date:"5/15/2020",
            source:"Manual",
            ref:"NA",
            days:"1",
            resource:"Ashwini Marathe",
        }]
    ngOnInit() { 
        $(document).ready(()=>{
            $("body").on("click", ".viewAuditStep", ()=>{
                this.addControl();
            })
        })
    }

    addControl(){
        this.formVisible = true;
    }

    cancelControlAddEdit(){
        this.formVisible = false;
    }

    backToAuditProcedureView(){
        this.router.navigate(['./pages/auditprocedure']);
    }

}