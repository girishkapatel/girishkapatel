import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageaudits',
  templateUrl: './manageaudits.component.html',
  styleUrls: ['./manageaudits.component.css']
})
export class ManageauditsComponent implements OnInit {
  constructor() { }
  ngOnInit() {}
}
