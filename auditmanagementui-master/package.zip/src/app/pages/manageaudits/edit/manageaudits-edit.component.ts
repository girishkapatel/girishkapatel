import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { tableColumn, tableData } from './../../../common/table/table.model'
import * as $ from 'jquery';

@Component({
    selector: 'app-auditedit',
    templateUrl: 'manageaudits-edit.component.html'
})
export class ManageauditsEditComponent implements OnInit {

    constructor(private router:Router) { }

    /* Scheduling Table Config*/
 
    tableColumnsScheduling:tableColumn[] = [{
        title:'Process',
        data:'process'
        },{
        title:'Quater',
        data:'quater'
        },{
        title:'Start Date',
        data:'startdate'
        },{
        title:'End Date',
        data:'enddate'
        },{
        title:'Total Man Days',
        data:'mandays'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green editSchedule"><i class="fa fa-eye"></i> View </a>';
        }
        }
    ]

    tableData_scheduling:tableData[]=[{
        id:1,
        process:"Procure To Pay",
        quater:"Q1",
        startdate:"01/04/2020",
        enddate:"31/06/2020",
        mandays:90
    }]
    
    /* Scheduling Table Config End*/

    /* Activity Table Config*/
    
    tableColumnsActivity:tableColumn[] = [{
        title:'Activity Name',
        data:'activity'
        },{
        title:'Planned Timeline',
        data:'planned'
        },{
        title:'Actual Timeline',
        data:'actual'
        },{
        title:'Status',
        data:'status'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green editActivity"><i class="fa fa-eye"></i> View </a>';
        }
        }
    ]

    tableData_activity:tableData[]=[{
        id:1,
        activity:"Activity 1",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    }]
    
    /* Activity Table Config End*/

    /* Workprogram Table Config*/
    
    tableColumnsWP:tableColumn[] = [{
      title:'Process L1',
      data:'processl1'
    },{
      title:'Process L2',
      data:'processl3'
    },{
      title:'Risk ID',
      data:'rid'
    },{
      title:'Risk Title',
      data:'rtitle'
    },{
      title:'Risk Description',
      data:'rdesc'
    },{
      title:'Risk Rating',
      data:'rating'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm red editWP"><i class="fa fa-edit"></i> Edit </a>';
      }
    }
  ] 

  tableData_wp:tableData[]=[{
    id:1,
    processl1:"Procure to Pay",
    processl3:"Invoice processing",
    rid:"PTP. R.01",
    rtitle:"Duplicate booking of invoices",
    rdesc:"Duplicate booking of invoices resulting due to lack of system restriction resulting into double payments ",
    rating:"High"
  }]
  
    /* Workprogram Table Config End*/

    /* Audit Procedure Table Config*/
 
    tableColumnsAP:tableColumn[] = [{
      title:'Procedure ID',
      data:'pid'
    },{
      title:'Procedure Title',
      data:'ptitle'
    },{
      title:'Business Cycle',
      data:'process'
    },{
      title:'Process L1',
      data:'l1'
    },{
      title:'Process L2',
      data:'l2'
    },{
      title:'Risk Title',
      data:'risk'
    },{
      title:'Company',
      data:'company'
    },{
      title:'Division',
      data:'division'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          let aHtml = '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm red editAuditProcedure"><i class="fa fa-edit"></i> Edit </a>';

          if(row.status === 'Inactive'){
            aHtml += '<a data-id="'+data+'" href="javascript:void(0);" class="btn btn-sm green initiateActivity"><i class="fa fa-edit"></i> Initiate </a>';
          }

          return aHtml;
      }
    }
  ]

  tableData_ap:tableData[]=[{
    id:1,
    pid:"PTP.P.01",
    ptitle:"Negative testing of system restriction",
    controlid:"PTP.C.01",
    control:"System restriction to process duplicate payment",
    process:"Procure To Pay",
    l1:"Accounts Payable",
    l2:"Invoice processing",
    risk:"Duplicate booking of invoices",
    status:"Active",
    company:"Tata Chemical Limited",
    division:"Chemical"
  }]

    auditColumns:tableColumn[] = [{
        title:'Internal Audit Areas',
        data:'area'
        },{
            title:'Risk Categorisation',
            data:'riskcat'
        },{
            title:'2020-21',
            data:'',
            render:(data)=>{
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small">';
            }
        },
        {
            title:'2021-22',
            data:'',
            render:(data)=>{
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small">';
            }
        }
        ,{
            title:'2022-23',
            data:'',
            render:(data)=>{
               return '<input type="checkbox" data-on-color="success" data-on-text="YES" data-off-color="default" data-off-text="NO" class="make-switch" data-size="small">';
            }
        }
    ]

    auditMapData:tableData[]=[
        {area:"Accounts Payable",riskcat:"High"},
        {area:"Sales and Marketing",riskcat:"High"},
        {area:"Logistics",riskcat:"High"},
        {area:"Plant Maintenance (Asset Care Management)",riskcat:"High"},
        {area:"Salt packing Centre (SPC)",riskcat:"High"},
        {area:"Safety, Health & Environment",riskcat:"High"},
        {area:"Compliances",riskcat:"High"},
        {area:"Capex",riskcat:"High"},
        {area:"Plant Operations review",riskcat:"High"},
        {area:"Related Party Transactions ( Half Yearly)",riskcat:"High"},
        {area:"SAP Control Review(All Modules)",riskcat:"High"},
        {area:"IT Controls Review Genral Controls",riskcat:"High"},
        {area:"IT Cyber Security",riskcat:"High"},
        {area:"IT  Data privacy ",riskcat:"High"},
        {area:"Outsourced Salt operations ",riskcat:"Medium"},
        {area:"Disaster Recovery Planning (Potential Natural and Security Risk)",riskcat:"Medium"},
        {area:"Internal Financial Control",riskcat:"Medium"}

    ]
    
    ngOnInit() {
        $(document).ready(()=>{
           
            $('body').on('click', '.editSchedule', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.showSchedulingForm('edit', schId);
            })

            $('body').on('click', '.editWP', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.showWorkprogramsForm('edit', schId);
            })

            $('body').on('click', '.editAP', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.showAuditprocedureForm('edit', schId);
            })
        })
        
    }
    
    showSchedulingForm(action:string, id:number){
        if(action === 'add'){
        this.router.navigate(['./pages/scheduling/add'])
        }

        if(action === 'edit'){
        this.router.navigate(['./pages/scheduling/edit'])
        }
    }

    showWorkprogramsForm(action:string, id:number){
        if(action === 'add'){
        this.router.navigate(['./pages/workprograms/add'])
        }

        if(action === 'edit'){
        this.router.navigate(['./pages/workprograms/edit'])
        }
    }

    showAuditprocedureForm(action:string, id:number){
        if(action === 'add'){
        this.router.navigate(['./pages/auditprocedure/add'])
        }

        if(action === 'edit'){
        this.router.navigate(['./pages/auditprocedure/edit'])
        }
    }

    backToAuditForm(){
        this.router.navigate(['./pages/manageaudits']);
    }

}