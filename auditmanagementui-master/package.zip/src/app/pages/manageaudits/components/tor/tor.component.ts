import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-tor',
    templateUrl: 'tor.component.html'
})
export class TorComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}