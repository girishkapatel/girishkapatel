import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-auditmemo',
    templateUrl: 'auditmemo.component.html'
})
export class AuditMemoComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}