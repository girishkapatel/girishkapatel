import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-followup',
  templateUrl: './followup.component.html',
  providers:[]
})
export class FollowupComponent implements OnInit{

  constructor() { }
  
  tableId:string = "followup_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Business Cycle',
    data:'bc'
  },{
    title:'Process L1',
    data:'pl1'
  },{
    title:'Process L2',
    data:'pl2'
  },{
    title:'Location',
    data:'loc'
  },{
    title:'Risk Rating',
    data:'rr'
  },{
    title:'Obervations',
    data:'obs'
  },{
    title:'Responsibility',
    data:'res'
  },{
    title:'Original Timeline',
    data:'ot'
  },{
    title:'Revised Timeline',
    data:'rt'
  },{
    title:'Status',
    data:'stat'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editFollowup"><i class="fa fa-edit"></i> Edit </a></p><p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm blue emailFollowup"><i class="fa fa-envelope"></i> Notify </a></p>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    bc:"Procure To Pay",
    pl1:"Accounts Payable",
    pl2:"Invoice Processing",
    loc:"Mithapur",
    rr:"High",
    obs:"Strengthen process of monitoring of Bill of Material (BOM)",
    res:"Mr. Abhimane",
    ot:"31/03/2020",
    rt:"",
    stat:"Implemented"
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveFollowup(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateFollowup();
    }else{
      this.addNewFollowup();
    }
  }

  addNewFollowup(){
    
  }

  updateFollowup(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addFollowup(){
    this.handleFormView.show();
  }

  editFollowup(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteFollowup(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editFollowup', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editFollowup();
        })
    })
  }
 
  
}
