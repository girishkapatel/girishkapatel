import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 


@Component({
    selector: 'app-activity',
    templateUrl: 'activity.component.html'
})
export class ActivityComponent implements OnInit {

    constructor() { }
    /* Activity Table Config*/
    tableId:string = "activity_table";
    tableColumnsActivity:tableColumn[] = [{
        title:'Activity Name',
        data:'activity'
        },{
        title:'Planned Timeline',
        data:'planned'
        },{
        title:'Actual Timeline',
        data:'actual'
        },{
        title:'Status',
        data:'status'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm red editActivity"><i class="fa fa-edit"></i> Edit </a>';
        }
        }
    ]

    tableData_activity:tableData[]=[{
        id:1,
        activity:"TOR circulated",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Kick off meeting announcement",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Planning of an audit",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Actual kick off meeting",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"MoM circulation",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Weekly status update",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Walkthrough",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Release of initial issue",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Discussion and validation",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Release of draft report",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Discussion of draft report",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"Release of final report",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    },{
        id:1,
        activity:"ACM Report",
        planned:"01/04/2020 to 31/06/2020",
        actual:"10/04/2020 to 31/06/2020",
        status:"Active"
    }]
    
    isEdit:boolean = false;
  

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveActivity(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateActivity();
    }else{
      this.addNewActivity();
    }
  }

  addNewActivity(){
    
  }

  updateActivity(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addActivity(){
    this.handleFormView.show();
  }

  editActivity(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteActivity(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editActivity', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editActivity();
        })
    })
  }

}