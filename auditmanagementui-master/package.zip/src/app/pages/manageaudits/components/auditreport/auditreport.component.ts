import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-auditreport',
    templateUrl: 'auditreport.component.html'
})
export class AuditReportComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}