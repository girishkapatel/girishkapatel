import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-datatracker',
  templateUrl: './datatracker.component.html',
  providers:[]
})
export class DataTrackerComponent implements OnInit{

  constructor() { }
  
  tableId:string = "datatracker_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Data required',
    data:'data'
  },{
    title:'Control Owner',
    data:'owner'
  },{
    title:'Expected Date',
    data:'expdate'
  },{
    title:'Receipt Status',
    data:'status'
  },{
    title:'Data Receipt Date',
    data:'recdate'
  },{
    title:'Delay (Days)',
    data:'delay'
  },{
    title:'Remarks',
    data:'remarks'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editDataTracker"><i class="fa fa-edit"></i> Edit </a></p><p class="mb-10"><a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm blue emailDataTracker"><i class="fa fa-envelope"></i> Email </a></p>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    data:'Screen shot of duplicate payment',
    owner:"Mr. Sambhaji Patil",
    expdate:"5/10/2020",
    status:"Pending",
    recdate:"",
    delay:"5",
    remarks:""
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveDataTracker(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateDataTracker();
    }else{
      this.addNewDataTracker();
    }
  }

  addNewDataTracker(){
    
  }

  updateDataTracker(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addDataTracker(){
    this.handleFormView.show();
  }

  editDataTracker(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteDataTracker(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editDataTracker', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editDataTracker();
        })
    })
  }
 
  
}
