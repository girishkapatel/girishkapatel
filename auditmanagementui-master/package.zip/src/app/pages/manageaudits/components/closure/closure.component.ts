import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-closure',
    templateUrl: 'closure.component.html',
    styleUrls: ['./closure.component.css']
})
export class ClosureComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}