import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-discussionnote',
    templateUrl: 'discussionnote.component.html'
})
export class DiscussionNoteComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}