import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-walkthrough',
  templateUrl: './walkthrough.component.html',
  providers:[]
})
export class WalkthroughComponent implements OnInit{

  constructor() { }
  
  tableId:string = "walkthrough_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Control ID',
    data:'cid'
  },{
    title:'Control Title',
    data:'ctitle'
  },{
    title:'Business Cycle',
    data:'cycle'
  },{
    title:'Process L1',
    data:'l1'
  },{
    title:'Process L2',
    data:'area'
  },{
    title:'Process Owner',
    data:'owner'
  },{
    title:'Location',
    data:'loc'
  },{
    title:'Date',
    data:'date'
  },{
    title:'Walkthrough Status',
    data:'wstat'
  },{
    title:'Walkthrough Result',
    data:'res'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editWalkthrough"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    cid:'PTP.C.01',
    ctitle:'System restriction to process duplicate payment',
    area:'Invoice Processing',
    cycle:"Procure To Pay",
    l1:"Accounts Payable",
    owner:"Mr Sambhaji More",
    loc:"Mithapur",
    date:"05/10/2019",
    wstat:"Completed",
    res:"Effective"
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveWalkthrough(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateWalkthrough();
    }else{
      this.addNewWalkthrough();
    }
  }

  addNewWalkthrough(){
    
  }

  updateWalkthrough(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addWalkthrough(){
    this.handleFormView.show();
  }

  editWalkthrough(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteWalkthrough(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editWalkthrough', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editWalkthrough();
        })
    })
  }
 
  
}
