import { Component, OnInit, ViewChild } from '@angular/core';
import { tableColumn, tableData } from './../../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery'; 

@Component({
  selector: 'app-testing',
  templateUrl: './testing.component.html',
  providers:[]
})
export class TestingComponent implements OnInit{

  constructor() { }
  
  tableId:string = "testing_table";
  
  tableGetApi:string='posts';
  
  tableColumns:tableColumn[] = [{
    title:'Control ID',
    data:'cid'
  },{
    title:'Control Title',
    data:'ctitle'
  },{
    title:'Business Cycle',
    data:'cycle'
  },{
    title:'Process L1',
    data:'l1'
  },{
    title:'Process L2',
    data:'area'
  },{
    title:'Process Owner',
    data:'owner'
  },{
    title:'Location',
    data:'loc'
  },{
    title:'Date',
    data:'date'
  },{
    title:'Testing Status',
    data:'wstat'
  },{
    title:'Testing Result',
    data:'res'
  },{
    title:'Action',
    data:'id',
    render:(data)=>{
      return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red editTesting"><i class="fa fa-edit"></i> Edit </a>';
    }
  }]

  tableData:tableData[] = [{
    id:1,
    cid:'PTP.C.01',
    ctitle:'System restriction to process duplicate payment',
    area:'Invoice Processing',
    cycle:"Procure To Pay",
    l1:"Accounts Payable",
    owner:"Mr Sambhaji More",
    loc:"Mithapur",
    date:"05/10/2019",
    wstat:"Completed",
    res:"Ineffective"
  }]

  isEdit:boolean = false;

  tableFilters = new BehaviorSubject({});

  formVisible:boolean = false;
  
  handleFormView = {
    show:()=>{
      this.formVisible = true;
    },
    hide:()=>{
      this.formVisible = false;
      this.isEdit = false; 
      this.clearform();
    }
  }

  cancelAddEdit(){
    this.handleFormView.hide();
  }

  saveTesting(e){
    e.preventDefault();
    if(this.isEdit){
      this.updateTesting();
    }else{
      this.addNewTesting();
    }
  }

  addNewTesting(){
    
  }

  updateTesting(){
    let postData = {
      id: 1,
      title: 'foo',
      body: 'bar',
      userId: 1
    }
  }

  addTesting(){
    this.handleFormView.show();
  }

  editTesting(){
    this.isEdit = true;
    this.handleFormView.show();
  }

  deleteTesting(){
    
  }

  clearform(){}

  ngOnInit() {
   $(document).ready(()=>{
        $('body').on('click', '.editTesting', (e)=>{
            let dataId = $(e.target).attr('id');
            this.editTesting();
        })
    })
  }
 
  
}
