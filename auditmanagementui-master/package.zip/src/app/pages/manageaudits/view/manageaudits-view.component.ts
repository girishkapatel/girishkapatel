import { Component, OnInit } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import * as $ from 'jquery';

@Component({
    selector: 'app-auditadd',
    templateUrl: 'manageaudits-view.component.html'
})
export class ManageauditsViewComponent implements OnInit {

    constructor(private router:Router) { }
    dataTitle:string = "In-Progress Audits";
     
    showGraph:boolean = false;
    showOngoing:boolean = true;
    showCompleted:boolean = false;
    showPlanned:boolean = false;
    showUnplanned:boolean = false;
    showAddAuditForm:boolean = false;
    
    tableColumns:tableColumn[] = [{
        title:'Audit Name',
        data:'name'
        },{
        title:'Status',
        data:'status'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+row.status + data+'" href="javascript:void(0);" class="btn btn-sm green editAudits"><i class="fa fa-eye"></i> View </a>';
        }
        }
    ]

    tableData_ongoing:tableData[]=[{
        id:1,
        name:"Procure To Pay",
        status:"In-Progress"
    },{
        id:1,
        name:"Compliances",
        status:"In-Progress"
    },{
        id:1,
        name:"Logistics",
        status:"In-Progress"
    }]

    tableData_completed:tableData[]=[{
        id:1,
        name:"Plant Operations review",
        status:"Completed"
    },{
        id:1,
        name:"Capex",
        status:"Completed"
    },{
        id:1,
        name:"Safety, Health & Environment",
        status:"Completed"
    },{
        id:1,
        name:"Sales and Marketing",
        status:"Completed"
    },{
        id:1,
        name:"Salt packing Centre (SPC)",
        status:"Completed"
    }]

    tableData_planned:tableData[]=[{
        id:1,
        name:"IT Data privacy",
        status:"Pending Initiation"
    },{
        id:1,
        name:"IT Cyber Security",
        status:"Pending Initiation"
    }]

    tableData_unplanned:tableData[]=[]
    
    ngOnInit() { 
        $(document).ready(()=>{
            $('body').on('click', '.editAudits', (e)=>{
                let dataId = $(e.target).attr('data-id');
                this.editAuditForm();
            })
        })
    }

    hideAll(){
        this.showGraph = false;
        this.showOngoing = false;
        this.showCompleted = false;
        this.showPlanned = false;
        this.showUnplanned = false;
    }
    
    showDataView(type:string){
        this.showGraph = type === 'graph' ?  true : false;    
    }

    showData(title:string){
        this.hideAll();
        this.dataTitle = title;
        switch (title) {
        case 'In-Progress Audits':
            this.showOngoing = true;
            break;
        case 'Audits Completed':
            this.showCompleted = true;
            break;
        case 'Audits to be Initiated':
            this.showPlanned = true;
            break;
        case 'Unplanned Audits':
            this.showUnplanned = true;
            break;
        }
    
    }

    addAuditForm(){
        this.router.navigate(['./pages/manageaudits/add']);
    }

    editAuditForm(){
        this.router.navigate(['./pages/manageaudits/edit']);
    }
    

}