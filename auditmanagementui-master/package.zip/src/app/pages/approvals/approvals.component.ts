import { Component, OnInit } from '@angular/core';
import { tableColumn, tableData } from './../../common/table/table.model'
import * as $ from 'jquery';
@Component({
  selector: 'app-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.css']
})
export class ApprovalsComponent implements OnInit {

  constructor() { }

  tableColumnsApproval:tableColumn[] = [{
        title:'Location',
        data:'Location'
        },{
        title:'Audit',
        data:'Audit'
        },{
        title:'Activity Type',
        data:'Activity'
        },{
        title:'Detail',
        data:'Detail'
        },{
        title:'	Responsibilty',
        data:'Responsibilty'
        },{
        title:'	Status',
        data:'Status',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green viewStatus"><i class="fa fa-eye"></i> View </a>';
        }
        },{
        title:'	Update',
        data:'Update'
        },{
        title:'	Comment',
        data:'Comment'
        }
    ]

    tableData_approval:tableData[]=[{
        "id":1,
        'Location':'Location',
        'Audit':'Audit',
        'Activity':'Activity Type',
        'Detail':'Detail',
        'Responsibilty':'	Responsibilty',
        'Status':'Status',
        'Update':'	Update',
        'Comment':'	Comment'
        }]

  ngOnInit() {
    $(document).ready(()=>{
      $('body').on('click', '.viewStatus', ()=>{
        window["jQuery"]("#basic").modal('show');
      })
    })
  }

}
