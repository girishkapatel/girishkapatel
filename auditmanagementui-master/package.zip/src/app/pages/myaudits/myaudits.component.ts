import { Component, OnInit, AfterViewInit } from '@angular/core';
import { tableColumn, tableData } from './../../common/table/table.model'
import * as $ from 'jquery';
import * as moment from 'moment'

@Component({
  selector: 'app-myaudits',
  templateUrl: './myaudits.component.html',
  styleUrls: ['./myaudits.component.css']
})
export class MyauditsComponent implements OnInit, AfterViewInit {

  constructor() { }

 /* Scheduling Table Config*/
 
 
tableColumnsAudit:tableColumn[] = [{
        title:'Location',
        data:'Location'
        },{
        title:'Audit',
        data:'Audit'
        },{
        title:'Head of Department',
        data:'hod'
        },{
        title:'Engagement Coordinator',
        data:'ec'
        },{
        title:'	Engagement Partner / Head of Audit',
        data:'ep'
        },{
        title:'	Start',
        data:'Start'
        },{
        title:'	End',
        data:'End'
        },{
        title:'	Status',
        data:'Status'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green editSchedule"><i class="fa fa-eye"></i> View </a>';
        }
        }
    ]

    tableData_audit:tableData[]=[]


    tableColumnsApproval:tableColumn[] = [{
        title:'Location',
        data:'Location'
        },{
        title:'Audit',
        data:'Audit'
        },{
        title:'Activity Type',
        data:'Activity'
        },{
        title:'Detail',
        data:'Detail'
        },{
        title:'	Responsibilty',
        data:'Responsibilty'
        },{
        title:'	Status',
        data:'Status'
        },{
        title:'	Update',
        data:'Update'
        },{
        title:'	Comment',
        data:'Comment'
        },{
        title:'Action',
        data:'id',
        render:(data, type, row, meta)=>{
            return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm green editSchedule"><i class="fa fa-eye"></i> View </a>';
        }
        }
    ]

    tableData_approval:tableData[]=[]

  
    
    /* Scheduling Table Config End*/
  ngOnInit() {

    
  }

  ngAfterViewInit(){
    $(document).ready(()=> {
            window["jQuery"]('#dashboard-report-range').daterangepicker({
                "ranges": {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                    'Last 7 Days': [moment().subtract('days', 6), moment()],
                    'Last 30 Days': [moment().subtract('days', 29), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                },
                "locale": {
                    "format": "MM/DD/YYYY",
                    "separator": " - ",
                    "applyLabel": "Apply",
                    "cancelLabel": "Cancel",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "Custom",
                    "daysOfWeek": [
                        "Su",
                        "Mo",
                        "Tu",
                        "We",
                        "Th",
                        "Fr",
                        "Sa"
                    ],
                    "monthNames": [
                        "January",
                        "February",
                        "March",
                        "April",
                        "May",
                        "June",
                        "July",
                        "August",
                        "September",
                        "October",
                        "November",
                        "December"
                    ],
                    "firstDay": 1
                },
                //"startDate": "11/08/2015",
                //"endDate": "11/14/2015",
                opens: (false ? 'right' : 'left'),
            }, function(start, end, label) {
                if ($('#dashboard-report-range').attr('data-display-range') != '0') {
                    $('#dashboard-report-range span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                }
            });
             if ($('#dashboard-report-range').attr('data-display-range') != '0') {
                $('#dashboard-report-range span').html(moment().subtract('days', 29).format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
            }
            $('#dashboard-report-range').show();
     })
  }

}
