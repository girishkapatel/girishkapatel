import { Component, OnInit } from '@angular/core';
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import {Router} from "@angular/router";
import * as $ from 'jquery';

@Component({
    selector: 'selector',
    templateUrl: 'workprograms-view.component.html'
})
export class WorkprogramsViewComponent implements OnInit {

    constructor(private router:Router) { }

    tableColumnsWP:tableColumn[] = [{
      title:'Business Cycle',
      data:'bc'
    },{
      title:'Process L1',
      data:'pl1'
    },{
      title:'Process L2',
      data:'pl2'
    },{
      title:'Risk ID',
      data:'rid'
    },{
      title:'Risk Title',
      data:'rtitle'
    },{
      title:'Risk Description',
      data:'rdesc'
    },{
      title:'Risk Rating',
      data:'rating'
    },{
      title:'Action',
      data:'id',
      render:(data, type, row, meta)=>{
          return '<a data-id="'+data+'" id="'+data+'" href="javascript:void(0);" class="btn btn-sm red editWP"><i class="fa fa-edit"></i> Edit </a>';
      }
    }
  ] 

  tableData_wp:tableData[]=[{
    id:1,
    bc:"Procure to Pay",
    pl1:"Accounts Payable",
    pl2:"Invoice processing",
    rid:"PTP. R.01",
    rtitle:"Duplicate booking of invoices",
    rdesc:"Duplicate booking of invoices resulting due to lack of system restriction resulting into double payments ",
    rating:"High"
  }]

    tableFilters = new BehaviorSubject({});
    ngOnInit() { 
        $(document).ready(()=>{
            $('body').on('click', '.editWP', (e)=>{
                e.preventDefault();
                let schId = $(e.target).attr('id');
                this.editWorkprograms();
            })
        })
    }

    editWorkprograms(){
        this.router.navigate(['./pages/workprograms/edit']);
    }

    addWorkprograms(){
        this.router.navigate(['./pages/workprograms/add']);
    }

}