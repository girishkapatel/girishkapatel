import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workprograms',
  templateUrl: './workprograms.component.html',
  styleUrls: ['./workprograms.component.css']
})
export class WorkprogramsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
