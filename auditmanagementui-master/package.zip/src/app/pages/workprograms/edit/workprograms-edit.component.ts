import { Component, OnInit, ViewChild } from '@angular/core';
import {Router} from "@angular/router"
import { tableColumn, tableData } from './../../../common/table/table.model'
import { BehaviorSubject } from 'rxjs';
import { NgForm } from '@angular/forms';

@Component({
    selector: 'selector',
    templateUrl: 'workprograms-edit.component.html'
})
export class WorkprogramsEditComponent implements OnInit {

    constructor(private router:Router) { }

    formVisible:boolean = false;
    
      tableColumns:tableColumn[] = [{
            title:'Control ID',
            data:'cid'
        },{
            title:'Control Title',
            data:'ctitle'
        },{
            title:'Control Description',
            data:'desc'
        },{
            title:'Control Frequency',
            data:'freq'
        },{
            title:'Control Type',
            data:'type'
        },{
            title:'Control Owner',
            data:'owner'
        },{
            title:'Control Nature',
            data:'nature'
        },{
            title:'Action',
            data:'id',
            render:(data)=>{
                return '<a id="'+ data+'" href="javascript:void(0);" class="btn btn-sm red removeControl"><i class="fa fa-close"></i> Delete </a>';
            }
        }]

        tableData:tableData[] = [{
            id:1,
            cid:"PTP.C.01",
            ctitle:"System restriction to process duplicate payment",
            desc:"System restricts booking of duplicate invoice based on the invoice number, invoice date and vendor name/code",
            freq:"Event driven",
            type:"Preventive",
            owner:"Mr. Sambhaji More",
            nature:"Automated"
        }]
    
    ngOnInit() { 

    }

    addControl(){
        this.formVisible = true;
    }

    cancelControlAddEdit(){
        this.formVisible = false;
    }

    backToWorkprogramsView(){
        this.router.navigate(['./pages/workprograms']);
    }

}