import { Component, OnInit, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms';
import {LoginService} from './login.service'
import { Router } from "@angular/router";
import * as $ from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userlogin:LoginService, private router:Router) { }
  
  showMessage:boolean;
  msgText:string = '';
  msgClass:string = '';
  role:string = '';

  @ViewChild('loginform', {static: false}) loginForm:NgForm;

  ngOnInit() {
    $('body').attr('class', 'login');
    localStorage.removeItem('userDetails');
  }

  userLogin(e){
    e.preventDefault();
    this.displayMessage("Authenticating...", "alert-success", false);
    if(this.validateCreds(this.loginForm.form.value)){
      // this.userlogin.login('api/login', this.loginForm.form.value).subscribe(response => {
      //   console.log(response);
      //   this.handleLogin(response);
      // }, error=>{
      //     this.handleError(error);
      // });

      if(this.loginForm.form.value.username === "admin" &&  this.loginForm.form.value.password === "ey@123"){
        this.role = "lead";
        this.handleLogin({login:true});
      }

      if(this.loginForm.form.value.username === "auditor" &&  this.loginForm.form.value.password === "ey@123"){
        this.role = "auditor";
        this.handleLogin({login:true});
      }
    }
  }

  handleError(error){
    let errorMessage = '';
    if(error.error && error.error.message){
      errorMessage = error.error.error;
    }else{
      errorMessage = 'Unable to login'
    }
    this.displayMessage(errorMessage, 'alert-danger');
  }


  handleLogin(response){
    this.displayMessage("Login Successful", "alert-success");
    localStorage.setItem('userDetails', JSON.stringify(response));
    localStorage.setItem('role', this.role);
    
    this.redirectToDashoard();
  }

  redirectToDashoard(){
    this.router.navigate(['./pages']);
  }

  displayMessage(msgText, msgClass, autohide=true){
      this.msgText = msgText;
      this.msgClass = msgClass;
      this.showMessage = true;
      if(autohide){
        setTimeout(() => {
          this.showMessage = false;
        }, 2000);
      }
  }

  validateCreds(creds:{[key:string]:string}){
      let isValid = false;
      if(creds.username && creds.password){
        isValid = true;
      }else{
        this.displayMessage("Username and Password cannot be blank", "alert-danger");
      }
      return isValid;
  }

}
